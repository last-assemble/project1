
# coding: utf-8

# In[1]:


import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
from sklearn.metrics.pairwise import linear_kernel
import tensorflow as tf
import numpy as np
import re
from googletrans import Translator


# In[ ]:


class Overview :
    
    # 원본 DataFrame과 영화 title을 인덱스로 하는 Series를 생성합니다.
    def fileLoad(path) : 
        
        file=pd.read_csv(path, encoding='utf-8')
        res=pd.Series(file.index, index=file['title'])
        
        return file, res
    
    # 영화간 유사도를 구한 후. cos_sim 객체를 출력합니다.
    def movie_cos_sim(file) : 
        
        tfidf=TfidfVectorizer(stop_words='english')
        tfidf_matrix=tfidf.fit_transform(file['overview'])
        cos_sim=linear_kernel(tfidf_matrix, tfidf_matrix)
        
        return cos_sim
    
    # 영화 샘플을 출력합니다.
    def title_sample(file) :
        
        movie_name=file['title'].sample(1).values[0]
        
        return movie_name
    
    # 유사도가 비슷한 영화의 인덱스를 출력합니다.
    def recommender_index(res, file, title, cos_sim, n) :
        
        idx=res[title]
        sim_scores=list(enumerate(cos_sim[idx]))
        sim_scores=sorted(sim_scores, key=lambda x:x[1], reverse=True)
        sim_scores=sim_scores[1:n+1]
        movie_res=[i[0] for i in sim_scores]
        cos_idx=file["title"].iloc[movie_res].index
            
        return cos_idx
    
    # 유사도가 비슷한 영화의 개요를 출력합니다.
    def overviews(file, index) :
        
        overviews=file.loc[index]['overview'].values
        string=""
        for view in overviews :
            if string=="" :
                string+=view
            else :
                string+=" "+view
        
        return string
    
    # 문자열로된 개요를 텍스트 파일로 저장합니다.
    def string_to_txt(path, string) :
        
        f=open(path, 'w', encoding='utf-8')
        f.write(string)
        f.close()
    
    # 영어로된 문장을 한글로 번역해줍니다.
    def translate(string) :

        trans=Translator()
        japen=trans.translate(string, src='en', dest='ja').text
        korea=trans.translate(japen, src='ja', dest='ko').text
        
        return korea

